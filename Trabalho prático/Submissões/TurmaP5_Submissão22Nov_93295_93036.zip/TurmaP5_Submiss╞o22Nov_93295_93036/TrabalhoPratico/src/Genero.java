
public enum Genero {
	MASCULINO, FEMININO;
}
