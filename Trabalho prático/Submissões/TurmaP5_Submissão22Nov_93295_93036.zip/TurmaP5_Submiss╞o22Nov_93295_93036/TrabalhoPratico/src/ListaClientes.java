import java.util.ArrayList;

public class ListaClientes {
	
	private ArrayList<Cliente> listaClientes;
	
	public ListaClientes() {
		listaClientes = new ArrayList<Cliente>();
	}
	
	public void addCliente(Cliente c) {
		listaClientes.add(c);
	}
	
	public void removeCliente(Cliente c) {
		assert !listaClientes.isEmpty() : "A lista de clientes est� vazia";
		listaClientes.remove(c);
	}
	
	public int size() {
		return listaClientes.size();
	}
	
	public Cliente[] getClientes() {
		assert !listaClientes.isEmpty() : "A lista de compras est� vazia";
		return listaClientes.toArray(new Cliente[size()]);
	}
}