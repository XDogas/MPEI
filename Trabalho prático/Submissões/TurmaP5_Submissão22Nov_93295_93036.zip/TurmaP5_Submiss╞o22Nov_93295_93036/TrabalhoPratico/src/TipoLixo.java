
public enum TipoLixo {
	ORGANICO, AZUL, AMARELO, VERDE;
}
